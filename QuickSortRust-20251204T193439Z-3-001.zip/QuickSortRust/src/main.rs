use rand::Rng;
use std::env;
use std::thread;
use std::time::Instant;

// ---------- QuickSort Secuencial ----------
fn quicksort_secuencial(arr: &mut [i32]) {
    if arr.len() < 2 {
        return;
    }

    let pivot_index = arr.len() / 2;
    let pivot = arr[pivot_index];
    let mut left = 0;
    let mut right = arr.len() - 1;

    while left <= right {
        while arr[left] < pivot {
            left += 1;
        }
        while arr[right] > pivot {
            if right == 0 {
                break;
            }
            right -= 1;
        }
        if left <= right {
            arr.swap(left, right);
            left += 1;
            if right == 0 {
                break;
            }
            right -= 1;
        }
    }

    if right > 0 {
        quicksort_secuencial(&mut arr[0..=right]);
    }
    quicksort_secuencial(&mut arr[left..]);
}

// ---------- QuickSort Paralelo ----------
fn quicksort_paralelo(arr: Vec<i32>, depth: usize) -> Vec<i32> {
    if arr.len() < 2 {
        return arr;
    }

    let pivot = arr[arr.len() / 2];
    let mut left_part = Vec::new();
    let mut right_part = Vec::new();

    for &x in arr.iter() {
        if x < pivot {
            left_part.push(x);
        } else if x > pivot {
            right_part.push(x);
        }
    }

    // Si queda todo igual al pivot (valores repetidos)
    let mut middle = arr.iter().filter(|&&x| x == pivot).cloned().collect::<Vec<_>>();

    if depth > 0 {
        let left_handle = thread::spawn(move || quicksort_paralelo(left_part, depth - 1));
        let right_sorted = quicksort_paralelo(right_part, depth - 1);

        let left_sorted = left_handle.join().unwrap();

        let mut result = left_sorted;
        result.append(&mut middle);
        result.extend(right_sorted);
        result
    } else {
        quicksort_secuencial(&mut left_part);
        quicksort_secuencial(&mut right_part);

        let mut result = left_part;
        result.append(&mut middle);
        result.extend(right_part);
        result
    }
}

// ---------- Función principal ----------
fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 3 {
        println!("Uso: cargo run --release <tamaño_del_arreglo> <profundidad_de_paralelismo>");
        return;
    }

    let n: usize = args[1].parse().unwrap();
    let depth: usize = args[2].parse().unwrap();

    let mut rng = rand::rng();
    let arr_seq: Vec<i32> = (0..n).map(|_| rng.random_range(0..100_000)).collect();
    let arr_par = arr_seq.clone();

    // ---- Ejecución secuencial ----
    let mut arr_seq_clone = arr_seq.clone();
    let start_seq = Instant::now();
    quicksort_secuencial(&mut arr_seq_clone);
    let tiempo_seq = start_seq.elapsed().as_secs_f64();

    // ---- Ejecución paralela ----
    let start_par = Instant::now();
    let _sorted = quicksort_paralelo(arr_par, depth);
    let tiempo_par = start_par.elapsed().as_secs_f64();

    // ---- Calcular Speedup ----
    let speedup = tiempo_seq / tiempo_par;

    println!("\n===== RESULTADOS =====");
    println!("Tamaño del arreglo: {}", n);
    println!("Profundidad de paralelismo: {}", depth);
    println!("Tiempo secuencial: {:.6} s", tiempo_seq);
    println!("Tiempo paralelo: {:.6} s", tiempo_par);
    println!("Speedup: {:.2}x", speedup);
}
