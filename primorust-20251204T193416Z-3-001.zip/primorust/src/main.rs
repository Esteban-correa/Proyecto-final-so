use std::time::Instant;
use std::thread;

const MAX_THREADS: usize = 4;
const N: u64 = 1_000_000;

fn es_primo(num: u64) -> bool {
    if num < 2 {
        return false;
    }
    if num == 2 {
        return true;
    }
    if num % 2 == 0 {
        return false;
    }
    let limite = (num as f64).sqrt() as u64;
    for i in (3..=limite).step_by(2) {
        if num % i == 0 {
            return false;
        }
    }
    true
}

fn contar_primos_secuencial(n: u64) -> usize {
    let mut count = 0;
    for i in 2..=n {
        if es_primo(i) {
            count += 1;
        }
    }
    count
}

fn contar_primos_paralelo(n: u64, num_threads: usize) -> usize {
    let rango = n / num_threads as u64;
    let mut handles = Vec::new();

    for i in 0..num_threads {
        let start = i as u64 * rango + 1;
        let end = if i == num_threads - 1 {
            n
        } else {
            (i as u64 + 1) * rango
        };

        handles.push(thread::spawn(move || {
            let mut count = 0;
            for j in start..=end {
                if es_primo(j) {
                    count += 1;
                }
            }
            count
        }));
    }

    let mut total = 0;
    for h in handles {
        total += h.join().unwrap();
    }
    total
}

fn main() {
    println!("Calculando números primos hasta {}...\n", N);

    let inicio_seq = Instant::now();
    let total_seq = contar_primos_secuencial(N);
    let duracion_seq = inicio_seq.elapsed().as_secs_f64();
    println!("Secuencial -> Primos: {} | Tiempo: {:.4} s", total_seq, duracion_seq);

    let inicio_par = Instant::now();
    let total_par = contar_primos_paralelo(N, MAX_THREADS);
    let duracion_par = inicio_par.elapsed().as_secs_f64();
    println!(
        "Paralelo ({} hilos) -> Primos: {} | Tiempo: {:.4} s",
        MAX_THREADS, total_par, duracion_par
    );

    let speedup = duracion_seq / duracion_par;
    println!("\nSpeedup: {:.2}x", speedup);
}
